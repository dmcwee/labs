Configuration Main
{

	Param ( 
		[PSCredential] $adminAccount,
		[String]$domainName
	)

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
	Import-DScResource -ModuleName 'ComputerManagementDsc'

    Node localhost
	{
        WindowsCapability RSAT-GPO
        {
            Name = "Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0"
            Ensure = "Present"
        }
    }
}