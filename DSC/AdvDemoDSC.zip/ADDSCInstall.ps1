Configuration Main
{
	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node localhost
	{
        Script InstallAzureADDSC {
            GetScript = {
                $result = Get-DscResource -Module ActiveDirectoryDSC
                return @{ 'Result' = $result }
            }
            SetScript = {
                Install-Module -Name ActiveDirectoryDSC -Repository PSGallery
            }
            TestScript = {
                $result = [scriptblock]::Create($GetScript).Invoke()

                if($result['Result'] -eq $null) {
                    return $true
                }
                else {
                    return $false
                }
            }
        }
    }
}